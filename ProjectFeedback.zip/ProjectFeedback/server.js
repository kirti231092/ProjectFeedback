const mongoose=require('mongoose')
const  express=require('express')
const cors=require('cors')
const app=express();

app.use(cors())
app.use(express.json());
const  port  = 5000

const AdminController=require('./controllers/AdminController')

const CustomerController=require('./controllers/CustomerController')

const ManagerController=require('./controllers/ManagerController')

const FeedbackController=require('./controllers/FeedbackController')

const ReplyController=require('./controllers/ReplyController')

mongoose.connect('mongodb://localhost:27017/feedbackdb',{
    useNewUrlParser: true,
    useUnifiedTopology: true,

}).then(()=>console.log("Mongodb connected"))
.catch(err => console.error('MongoDB connection error:', err));

//admin API
app.post('/adminlogin', AdminController.adminLogin);

// Customer API 

app.post('/getallcustomers', CustomerController.getAllCustomers);

app.post('/customerregistrations', CustomerController.createCustomerRegistration);

app.post('/customerlogin', CustomerController.customerLogin);


//Feedback API
app.post('/createfeedback', FeedbackController.createFeedback);

app.post('/getAllFeedbacks', FeedbackController.getAllFeedbacks);

app.post('/getfeedbackbycustomerid/:custid', FeedbackController.getFeedbackByCustomerId );

app.post('/getfeedbackbyrating/:feedrate', FeedbackController.getFeedbackByRating );

app.put('/editfeedback/:feedbackId', FeedbackController.editFeedback);

app.delete('/deletefeedback/:id', FeedbackController.deleteFeedbackById);


//Manager API
app.post('/registermanager', ManagerController.createManagerRegistration);
app.post('/getallmanagers', ManagerController.getAllManagers);
app.post('/loginmanager', ManagerController.managerLogin);
app.delete('/deletemanager/:id', ManagerController.deleteManagerById);
app.put('/editmanager/:id', ManagerController.editManager);


//Reply API
app.post('/createreply', ReplyController.createReply);
app.post('/getallreplys', ReplyController.getAllReply);
app.post('/getreplybycustomerid/:custid', ReplyController.getReplyByCustomerId);
app.post('/getreplybymanagerid/:manageruserid', ReplyController.getReplyByManagerId);
app.post('/getreplybyfeedbackid/:feedbackid', ReplyController.getReplyByFeedbackId);
app.put('/editreply/:id', ReplyController.editReply);
app.delete('/deletereply/:id', ReplyController.deleteReplyById);




// app.post('/logout', (req, res) => {
//     res.status(200).json({ message: 'Logged out successfully' });
//   });
  

app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
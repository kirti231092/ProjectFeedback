const Manager = require('../models/Manager');

exports.createManagerRegistration = async (req, res) => {
    try {
        const { userid, email, password, fullname, departmentname, mobile } = req.body;


        if (!userid || !email || !password || !mobile || !fullname || !departmentname) {
            return res.status(400).json({ message: 'All fields are required' });
        }


        const manager = new Manager({
            userid,
            email,
            password,
            fullname,
            departmentname,
            mobile
        });

        const savedManagerRegistration = await manager.save();

        if (!savedManagerRegistration) {
            return res.status(400).json({ message: 'Registration not inserted' });
        }

        res.status(201).json(savedManagerRegistration);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};


exports.getAllManagers = async (req, res) => {
    try {
        const managers = await Manager.find();
        res.json(managers);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.managerLogin = async (req, res) => {
    try {
        const { email, password } = req.body;

        console.log("email is:" + email + "password is:" + password)
        const manager = await Manager.findOne({ email });
        console.log("email is:" + manager.email + "password is:" + manager.password)
        if (!manager) {
            return res.status(400).json({ message: 'manager not found' });
        }


        if (manager.password !== password) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }


        const managerResponse = {
            fullname: manager.fullname,
            email: manager.email,
        };


        res.status(200).json({ message: 'Login successful', manager: managerResponse });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};


exports.deleteManagerById = async (req, res) => {
    try {
        const { id } = req.params;

        const deletedManager = await Manager.findByIdAndDelete(id);

        if (!deletedManager) {
            return res.status(404).json({ message: 'Manager not found' });
        }

        res.status(200).json({ message: 'Manager deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.editManager = async (req, res) => {
    try {
        const { id } = req.params;
        console.log("Manager id is :"+id)
        const { userid,email, password, fullname, departmentname, mobile } = req.body; 

        const updatedManager = await Manager.findByIdAndUpdate(
            id,
            {
                userid,
                email,
                password,
                fullname,
                departmentname,
                mobile
            },
            { new: true }
        );

        if (!updatedManager) {
            return res.status(404).json({ message: 'Manager not found' });
        }

        res.status(200).json(updatedManager);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

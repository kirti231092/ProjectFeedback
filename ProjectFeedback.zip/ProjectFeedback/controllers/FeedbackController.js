const Feedback = require('../models/Feedback')
exports.createFeedback = async (req, res) => {
  try {
    const { custid, feedbackdesc, feedrate } = req.body;

    if (!feedbackdesc && !feedrate) {
      return res.status(400).json({ message: 'Feedback message is required' });
    }

    const newFeedback = new Feedback({
      custid,
      feedbackdesc,
      feedrate
    });

    const savedFeedback = await newFeedback.save();

    if (!savedFeedback) {
      return res.status(400).json({ message: 'Feedback not saved' });
    }

    res.status(201).json(savedFeedback);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAllFeedbacks = async (req, res) => {
  try {
  
    const feedbacks = await Feedback.find();

    if (!feedbacks || feedbacks.length === 0) {
      return res.status(400).json({ message: 'Feedback not found' });
    }


    res.status(200).json(feedbacks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


exports.getFeedbackByCustomerId = async (req, res) => {
  try {
    const { custid } = req.params;  
    const feedbacks = await Feedback.find({ custid: custid });  
    console.log("custid is:",custid)
    if (!feedbacks || feedbacks.length === 0) {
      return res.status(404).json({ message: 'Feedback not found' }); 
    }

    res.status(200).json(feedbacks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


exports.getFeedbackByUsername = async (req, res) => {
  try {
    const { username } = req.params;


    const feedbacks = await Feedback.find({ username : username });

    if (!feedbacks || feedbacks.length === 0) {
      return res.status(400).json({ message: 'Feedback not found' });
    }


    res.status(200).json(feedbacks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getFeedbackByRating = async (req, res) => {
  try {
    const { feedrate } = req.params;
    
    if (!feedrate) {
      return res.status(400).json({ message: 'feedrate is required' });
    }

    const feedbacks = await Feedback.find({ feedrate : feedrate});

    if (!feedbacks || feedbacks.length === 0) {
      return res.status(404).json({ message: 'Feedback not found' });
    }

    res.status(200).json(feedbacks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.deleteFeedbackById = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedFeedback = await Feedback.findByIdAndDelete(id);

    if (!deletedFeedback) {
      return res.status(404).json({ message: 'Feedback not found' });
    }

    res.status(200).json({ message: 'Feedback deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.editFeedback = async (req, res) => {
  try {
    const { feedbackId } = req.params;
 
    const updatedFeedback = await Feedback.findByIdAndUpdate(
      feedbackId,
      {
        $set: {
          custid: req.body.custid,
          feedbackdesc: req.body.feedbackdesc,
          feedrate: req.body.feedrate
        }
    },  { new: true } )


    if (!updatedFeedback) {
      return res.status(404).json({ message: 'Feedback not found' });
    }

    res.status(200).json(updatedFeedback);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
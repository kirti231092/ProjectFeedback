const Reply = require('../models/Reply')
exports.createReply = async (req, res) => {
    try {
        const { feedbackid, custid, replymessage, manageruserid } = req.body;

        // Validate that replymessage is provided
        if (!replymessage) {
            return res.status(400).json({ message: 'Reply message is required' });
        }

        // Create a new reply instance
        const newReply = new Reply({
            feedbackid,
            custid,
            replymessage,
            manageruserid
        });

        // Save the reply to the database
        const savedReply = await newReply.save();

        // Return the saved reply as the response
        res.status(201).json(savedReply);
    } catch (err) {
        // Return a 500 error with the error message
        res.status(500).json({ message: err.message });
    }
};


exports.getAllReply = async (req, res) => {
    try {

        const replys = await Reply.find();

        if (!replys || replys.length === 0) {
            return res.status(400).json({ message: 'Reply not found' });
        }


        res.status(200).json(replys);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getReplyByCustomerId = async (req, res) => {
    try {
        const { custid } = req.params;


        const replys = await Reply.find({ custid:custid });

        if (!replys || replys.length === 0) {
            return res.status(400).json({ message: 'Reply not found' });
        }


        res.status(200).json(replys);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getReplyByManagerId = async (req, res) => {
    try {
        const { manageruserid } = req.params;


        const replys = await Reply.find({ manageruserid });

        if (!replys || replys.length === 0) {
            return res.status(400).json({ message: 'Reply not found' });
        }


        res.status(200).json(replys);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getReplyByFeedbackId = async (req, res) => {
    try {
        const { feedbackid } = req.params;


        const replys = await Reply.find({ feedbackid });

        if (!replys || replys.length === 0) {
            return res.status(400).json({ message: 'Reply not found' });
        }


        res.status(200).json(replys);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.deleteReplyById = async (req, res) => {
    try {
        const { id } = req.params;

        const deletedReply = await Reply.findByIdAndDelete(id);

        if (!deletedReply) {
            return res.status(404).json({ message: 'Reply not found' });
        }

        res.status(200).json({ message: 'Reply deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.editReply = async (req, res) => {
    try {
        const { id } = req.params;
        const { feedbackid, custid, replymessage, manageruserid } = req.body;

        if (!replymessage) {
            return res.status(400).json({ message: 'Reply message is required' });
        }

        const updateData = {};
        if (feedbackid) updateData.feedbackid = feedbackid;
        if (custid) updateData.custid = custid;
        if (replymessage) updateData.replymessage = replymessage;
        if (manageruserid) updateData.manageruserid = manageruserid;

        
        const updatedReply = await Reply.findByIdAndUpdate(
            id,
            updateData,
            { new: true }
        );

        
        if (!updatedReply) {
            return res.status(404).json({ message: 'Reply not found' });
        }
        res.status(200).json(updatedReply);
    } catch (err) {
       
        res.status(500).json({ message: err.message });
    }
};

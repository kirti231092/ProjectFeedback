const Customer = require('../models/Customer');

exports.createCustomerRegistration = async (req, res) => {
  try {
    const { username, email, password, mobile } = req.body;


    if (!username || !email || !password || !mobile) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Create a new registration entry
    const customer = new Customer({
      username,
      email,
      password,
      mobile,
    });

    const savedCustomerRegistration = await customer.save();

    if (!savedCustomerRegistration) {
      return res.status(400).json({ message: 'Registration not inserted' });
    }

    res.status(201).json(savedCustomerRegistration);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


exports.getAllCustomers = async (req, res) => {
  try {
    const customers = await Customer.find();
    res.json(customers);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.customerLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log("email is:" + email + "password is:" + password)
    const user = await Customer.findOne({ email });
    console.log("email is:" + user.email + "user.password is:" + password + "nameis" + user.name)
    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }


    if (user.password !== password) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }


    const userResponse = {
      username: user.username,
      email: user.email,
      mobile: user.mobile,
    };


    res.status(200).json({ message: 'Login successful', user: userResponse });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
const Admin = require('../models/Admin');


exports.adminLogin = async (req, res) => {
  try {
    const { userid, password } = req.body;

    console.log("userid is:" + userid + "password is:" + password)
    const admin = await Admin.findOne({ userid });
    console.log("userid is:" + admin.userid + "password is:" + admin.password)
    if (!admin) {
      return res.status(400).json({ message: 'Admin not found' });
    }


    if (admin.password !== password) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    res.status(200).json({ message: 'Login successful' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
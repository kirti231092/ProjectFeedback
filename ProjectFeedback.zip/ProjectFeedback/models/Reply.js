const mongoose = require('mongoose');

const replySchema = new mongoose.Schema({
    feedbackid: { type: String, required: true },
    custid: { type: String, required: true, unique: true }, 
    replymessage: { type: String, required: true }, 
    manageruserid: { type: String, required: true }
});  

module.exports = mongoose.model('Reply', replySchema, 'reply');

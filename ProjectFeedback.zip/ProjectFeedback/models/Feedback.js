const mongoose = require('mongoose');

const feedbackSchema = new mongoose.Schema({
    custid: { type: String, required: true },
    feedbackdesc: { type: String, required: true, unique: true }, 
    feedrate: { type: String, required: true }
}, );  

module.exports = mongoose.model('Feedback', feedbackSchema, 'feedback');

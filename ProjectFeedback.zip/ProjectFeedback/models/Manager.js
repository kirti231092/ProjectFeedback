const mongoose = require('mongoose');

const managerSchema = new mongoose.Schema({
    userid: { type: String, required: true },
    password: { type: String, required: true },
    departmentname: { type: String, required: true, unique: true }, 
    fullname: { type: String, required: true, unique: true },  
    email: { type: String, required: true, unique: true }, 
    mobile: { type: Number, required: true }
}, );  

module.exports = mongoose.model('Manager', managerSchema, 'manager');
